/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.1
        Device            :  dsPIC33EV64GM102
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.70
        MPLAB 	          :  MPLAB X v5.50
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/
#include <stdbool.h>
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/boot/boot_demo.h"

unsigned int a=0,k=0,test,H=20000,L=40000;
bool b,d, S;
extern unsigned int bootloader_flag;
//#define H 20000
//#define L 40000
//#define LED _RA2
#define LED _TRISA2
#define LEDIN _RA2

/*
                         Main application
 */
int main(void)
{
    // initialize the device
    volatile uint16_t dummy;

    // 1) disable UART
    U1STAbits.UTXEN = 0;     // disable transmitter
    U1MODEbits.UARTEN = 0;   // disable module

    // kr�tk� ?ek�n�, aby se hardware ust�lil
    for (volatile int i=0; i<1000; ++i) { asm("nop"); }

    // 2) vypr�zdn?n� RX FIFO (dummy read)
    while (U1STAbits.URXDA) {
        dummy = U1RXREG;
        (void)dummy;
    }

    // 3) clear status flags (overrun atd.)
    if (U1STAbits.OERR) U1STAbits.OERR = 0;   // clear overrun
    // FERR nelze "nastavit na 0" p?�mo, mus� se obvykle vy?�st RXREG - u? jsme to ud?lali
    IFS0bits.U1RXIF = 0;
    IFS0bits.U1TXIF = 0;
    IFS4bits.U1EIF  = 0; // pokud existuje

// Disable DMA module 
    DMA0CONbits.CHEN = 0;
  // DMACONbits.SUSPEND = 1;   // suspend all transfers
    IFS0bits.DMA0IF = 0;      // clear possible flags
    SYSTEM_Initialize();
    //_TRISB2=0;
    //_RB2=d;//t rled
    //bootloader_flag = 1; // test//Vymaz�n� vlajky
   // RCONbits.WDTO=0; 
    BOOT_DEMO_Initialize();
     b=(bootloader_flag == 0xA5A5);
     bootloader_flag = 0; // Vymaz�n� vlajky
     S=1; //newtest
   // if(!LEDIN)
   //     b= true;
    while (1)
    {        
        // Add your application code
         __asm__("clrwdt");
         /*
         if(!_RA1)
         {
             bootloader_flag = 0xA5A5;
             while(1)
             {}
         }
          * */
        a++;
        if(LED )
        {
         if(a>H)
         { 
             LEDIN=0;
             LED=0;
             a=0;
             k++;
         }
        }
        else
        {
         if(a>L)
         {
             LED=1;
             a=0;
             
         }
        }
        if(k>10)
        {
  
            if(S)
            {
                S=0;
                if((!_RB5) & _RB6)
                    b=1;
            }

            BOOT_DEMO_Tasks();
        }

    }
    return 1; 
}
/**
 End of File
*/

